import { Component, OnInit } from '@angular/core';
import { AddPayeeService } from '../add-payee.service';
import { userprofile } from './userprofile';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

  allCust:userprofile=new userprofile();

  constructor(private customerservice:AddPayeeService) { }

  ngOnInit(): void {

    console.log("loading customers");
    this.loadAllCustomers();

  }
  loadAllCustomers() {
    console.log('Load all customers');
    this.customerservice.getCustomerService().subscribe(
      (data: userprofile)=> 
      {
        this.allCust = data;
        //this.tempEmployees = data; //copied into a temp array also
      }, 
      (err) => {
        console.log(err);
      }
    );

  }

}
