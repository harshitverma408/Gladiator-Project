import { Component, OnInit } from '@angular/core';
import { AddPayeeService } from '../add-payee.service';
import { Approvals } from './Approvals';

@Component({
  selector: 'app-approval',
  templateUrl: './approval.component.html',
  styleUrls: ['./approval.component.css']
})
export class ApprovalComponent implements OnInit {

  allApprovals:Approvals[]=[];
  accept:Approvals=new Approvals();

  constructor(private approvalservice:AddPayeeService) { }

  ngOnInit(): void {

    console.log("loading payees");
    this.loadAllApprovals();

  }
  loadAllApprovals() {
    console.log('Load all payees');
    this.approvalservice.getApprovalService().subscribe(
      (data:Approvals[])=> 
      {
        this.allApprovals = data;
        //this.tempEmployees = data; //copied into a temp array also
      }, 
      (err) => {
        console.log(err);
      }
    );

  }
  approve(){
    // console.log(this.allApprovals.custId + ) ;
    this.approvalservice.approveservice(this.accept).subscribe(
      (data:Approvals[])=> 
      {
        // this.accept = data;
        //this.tempEmployees = data; //copied into a temp array also
      }, 
      (err) => {
        console.log(err);
      }
    );

  }

}
