import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Payee } from './add-payee/Payee';
import { Transaction } from './account-statement/Transaction';
import { userprofile } from './user-profile/userprofile';
import { CustomerDetails } from './open-account/CustomerDetails';
import { Approvals } from './approval/Approvals';
import { ApprovalComponent } from './approval/approval.component';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { Account } from './account-input/Account';

@Injectable({
  providedIn: 'root'
})
export class AddPayeeService {

  urls:string;
  postPayee = 'addPayee/10008'
  baseURL: string = 'http://localhost:8085/payee/addPayee/10008'
  getURL:string='http://localhost:8085/payee/getPayee/10008'
  transURL:string='http://localhost:8085/transaction/getTrans/10008'
  custURL:string='http://localhost:8085/customer/getCustomer/101'
  custAddURL:string='http://localhost:8085/customer/addCust'
  loginURL:string='http://localhost:8085/loginpage/login/sid07/Sid07@ath'
  approveURL:string ='http://localhost:8085/approval/approveAccount/109/55599' 
  approvalURL:string ='http://localhost:8085/approval/accToApprove'
  addAccountURL:string = 'http://localhost:8085/account/addAccount/104'  
  constructor(private myhttp: HttpClient) { }

  addPayeeService(payee:Payee): Observable<any> {
    
    console.log(payee);
    console.log("post is working");
    return this.myhttp.post<any>(this.baseURL,payee);
    // return this.myhttp.post('${this.baseURL}',payee);
    // return this.http.post(`${this.baseUrl}`+'/addquestion', addQuestion)
    
}
getPayeeService(): Observable<Payee[]> {
  console.log("getPayeeservice called..")
 return this.myhttp.get<Payee[]>(this.getURL);
}
 getTransactionService(): Observable<Transaction[]> {
 console.log("getPayeeservice called..")
 return this.myhttp.get<Transaction[]>(this.transURL);
}

getCustomerService():Observable<userprofile>
{
  console.log("getCustomer called...");
  return this.myhttp.get<userprofile>(this.custURL);
}

addCustomerService(cust:CustomerDetails): Observable<any> {
    
  console.log(cust);
  console.log("post is working");
  return this.myhttp.post<any>(this.custAddURL,cust);
  // return this.myhttp.post('${this.baseURL}',payee);
  // return this.http.post(`${this.baseUrl}`+'/addquestion', addQuestion)
  
}
getLoginService():Observable<any>{
  console.log("getLoginService called...");
  //console.log(allLogin);
    return this.myhttp.get<any>(this.loginURL);
}

getApprovalService(): Observable<Approvals[]> {
  console.log("getPayeeservice called..")
 return this.myhttp.get<Approvals[]>(this.approvalURL);
}
approveservice(a:Approvals): Observable<any> {
  
  console.log("approve service called..")
   
 return this.myhttp.post<any>(this.approveURL,a);
}
addAccountService(acc:Account): Observable<any> {
    
  console.log(acc);
  console.log("account  is working");
  return this.myhttp.post<any>(this.addAccountURL,acc);
  // return this.myhttp.post('${this.baseURL}',payee);
  // return this.http.post(`${this.baseUrl}`+'/addquestion', addQuestion)
  
}


}
