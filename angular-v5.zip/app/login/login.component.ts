import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AddPayeeService } from '../add-payee.service';
import { user } from './user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  allLogin: user=new user();
  userid: String;
  password:String;
  logincheck:boolean;

  constructor(private loginservice:AddPayeeService,private router:Router) { }

  ngOnInit(): void {
    //console.log("authenticating..");
    //this.authenticate(userid,login);
  }
  authenticate(){
    console.log("inside authenticate...")
    this.loginservice.getLoginService().subscribe(
      (data:user)=>
      {
        console.log(data);
       if(data.toString()=='true'){
         this.logincheck=true;
         console.log(this.logincheck);
         
       }
       else{
         this.logincheck=false;
    
       }
       
        this.allLogin = data;
        //console.log(this.allLogin);
         console.log("Response received");
         
         
    },
     
  
          //copied into temp array
      (err)=>{
          console.log(err);
      }
    );
    
  }
  registerIb(){
    this.router.navigate(['/register-ib']);
  }
 forgotPassword(){
    this.router.navigate(['/forgot-pw']);
  }
 forgotUserId(){
    this.router.navigate(['/forgot-id']);
  }
  goToDashBoard(){
    this.authenticate();
    this.router.navigate(['/dashboard']);


  }

}
