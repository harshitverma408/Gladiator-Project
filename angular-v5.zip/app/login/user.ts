export class user{
    userid:string|undefined;
    password:string|undefined;
}