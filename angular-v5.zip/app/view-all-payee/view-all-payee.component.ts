import { Component, OnInit } from '@angular/core';
import { AddPayeeService } from '../add-payee.service';
import { Payee } from '../add-payee/Payee';

@Component({
  selector: 'app-view-all-payee',
  templateUrl: './view-all-payee.component.html',
  styleUrls: ['./view-all-payee.component.css']
})
export class ViewAllPayeeComponent implements OnInit {

  allPayee:Payee[]=[];

  constructor(private payeeservice:AddPayeeService) { }

  ngOnInit(): void {

    console.log("loading payees");
    this.loadAllEmployees();

  }
  loadAllEmployees() {
    console.log('Load all payees');
    this.payeeservice.getPayeeService().subscribe(
      (data: Payee[])=> 
      {
        this.allPayee = data;
        //this.tempEmployees = data; //copied into a temp array also
      }, 
      (err) => {
        console.log(err);
      }
    );

  }

}
