export class Account{
   
    accounttype:string;
    accountnumber:number;
    currentbalance:string;
    loginpassword: string;
    transactionpassword: string;
    userid:string;
  
   
}