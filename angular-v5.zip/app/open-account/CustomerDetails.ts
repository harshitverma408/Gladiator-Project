export class CustomerDetails{
    custid: number;
    debitcard: string;
    dob:string;
    email: string;
    fathername:string;
    firstname:string;
    grossannualincome: string;
    incomesource:string;
    initialamount:string;
    lastname: string;
    middlename:string;
    mobilenumber:string;
    occupationtype:string;
    optnetbanking: string;
    city: string
    landmark:string;
    line1: string;
    line2: string;
    pincode: number;
    state: string;
    title: string;
    aadharnumber: number;
}