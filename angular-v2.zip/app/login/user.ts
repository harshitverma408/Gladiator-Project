export class user{
    userid:string|undefined;
    
}