import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginComponent } from '../login/login.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }
  adminLogin(){
    this.router.navigate(['/admin']);
    
  }
  login(){
    this.router.navigate(['/login']);
  }
  registerIb(){
    this.router.navigate(['/register-ib']);
  }

  openAccount(){
    this.router.navigate(['/open-account']);
  }


}
