import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-imps',
  templateUrl: './imps.component.html',
  styleUrls: ['./imps.component.css']
})
export class ImpsComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  showTransactionDetails(){
    this.router.navigate(['/transaction']);
  }

}
