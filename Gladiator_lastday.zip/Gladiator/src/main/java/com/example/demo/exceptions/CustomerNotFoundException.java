package com.example.demo.exceptions;

public class CustomerNotFoundException extends Exception {
	public CustomerNotFoundException(String str) {
		super(str);
	}
}