package com.example.demo.exceptions;

public class AccountNotFoundException extends Exception {
	public AccountNotFoundException(String str) {
		super(str);
	}
}