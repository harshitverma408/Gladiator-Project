package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.exceptions.PayeeNotFoundException;
import com.example.demo.layer2.Accountdetail;
import com.example.demo.layer2.Payee;

@Repository
public class PayeeRepositoryIMPL extends BaseRepository implements PayeeRepository {

	    @Transactional
	    public void insertPayee(int accNo,Payee ref) {
	        EntityManager entityManager = getEntityManager();
	        Accountdetail acc = (Accountdetail) entityManager.createQuery("select a from Accountdetail a where a.accountnumber =: accNo").setParameter("accNo", accNo).getSingleResult();
	        ref.setAccountdetail(acc);
	        entityManager.merge(ref);
	        System.out.println("Payee inserted..."+ref);
	    }
	 
	    @Override
	    public List<Payee> selectPayee(int AccNo) throws PayeeNotFoundException {
	    	Query query = entityManager.createQuery("from Payee");
	        List<Payee> PayeeList = query.getResultList();
	        List<Payee> FinalList = new ArrayList<>();
	        for (Payee payee : PayeeList) {
	        	if(payee.getAccountdetail().getAccountnumber()==AccNo) {
	        		FinalList.add(payee);
	        	}
			}
	        return FinalList;
	    }
	 
	    @Override
	    public List<Payee> selectAllPayee() {
	        System.out.println("PayeeRepository : Layer 3");
	        EntityManager entityManager = getEntityManager();
	        Query query = entityManager.createQuery("from Payee");
	        List<Payee> PayeeList = query.getResultList();
	        return PayeeList;
	    }

	    @Transactional
	    public void deletePayee(int BeneficiaryId) throws PayeeNotFoundException {
	        EntityManager entityManager = getEntityManager();
	        Payee foundPayee = entityManager.find(Payee.class, BeneficiaryId);
	        if(foundPayee!=null)
	        	entityManager.remove(foundPayee);
	        else
	            throw new PayeeNotFoundException("Payee Not Found : "+BeneficiaryId);
	        System.out.println("Payee removed ... ");
	    }

}
