import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-rtgs',
  templateUrl: './rtgs.component.html',
  styleUrls: ['./rtgs.component.css']
})
export class RtgsComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  showTransactionDetails(){
    this.router.navigate(['/transaction']);
  }
}
