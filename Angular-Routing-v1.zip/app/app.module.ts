import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { OpenAccountComponent } from './open-account/open-account.component';
import { RegisterInternetBankingComponent } from './register-internet-banking/register-internet-banking.component';
import { ForgotUseridComponent } from './forgot-userid/forgot-userid.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { AccountLockedComponent } from './account-locked/account-locked.component';
import { SetNewPasswordComponent } from './set-new-password/set-new-password.component';
import { FormsModule } from '@angular/forms';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { HomeComponent } from './home/home.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AccountStatementComponent } from './account-statement/account-statement.component';
import { ImpsComponent } from './imps/imps.component';
import { AdminComponent } from './admin/admin.component';
import { RtgsComponent } from './rtgs/rtgs.component';
import { ApprovalComponent } from './approval/approval.component';
import { NeftComponent } from './neft/neft.component';
import { AddPayeeComponent } from './add-payee/add-payee.component';
import { TransactionComponent } from './transaction/transaction.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { ChangeUserIdComponent } from './change-user-id/change-user-id.component';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { AccountSummaryComponent } from './account-summary/account-summary.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    OpenAccountComponent,
    RegisterInternetBankingComponent,
    ForgotUseridComponent,
    ForgotPasswordComponent,
    AccountLockedComponent,
    SetNewPasswordComponent,
    PageNotFoundComponent,
    HomeComponent,
    DashboardComponent,
    AccountStatementComponent,
    ImpsComponent,
    AdminComponent,
    RtgsComponent,
    ApprovalComponent,
    NeftComponent,
    AddPayeeComponent,
    TransactionComponent,
    UserProfileComponent,
    ChangeUserIdComponent,
    AccountDetailsComponent,
    AccountSummaryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
