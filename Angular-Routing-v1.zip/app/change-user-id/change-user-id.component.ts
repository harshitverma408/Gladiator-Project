import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-change-user-id',
  templateUrl: './change-user-id.component.html',
  styleUrls: ['./change-user-id.component.css']
})
export class ChangeUserIdComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  dashboard(){
    this.router.navigate(['/dashboard']);
  }
}
