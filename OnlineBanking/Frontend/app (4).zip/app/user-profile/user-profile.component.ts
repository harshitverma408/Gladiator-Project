import { Component, OnInit } from '@angular/core';
import { AccDetails } from '../account-details/AccDetails';
import { AddPayeeService } from '../add-payee.service';
import { userprofile } from './userprofile';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

  allCust:userprofile=new userprofile();
  allAcc:AccDetails;
  temp:any;
  getCust:userprofile;

  constructor(private customerservice:AddPayeeService) { 
    this.temp=sessionStorage.getItem("userKey");
    this.allAcc=JSON.parse(this.temp);
  }

  ngOnInit(): void {

    console.log("loading customers");
    this.loadAllCustomers();

  }
  loadAllCustomers() {
    console.log('Load all customers');
    this.customerservice.getCustomerService(this.allAcc).subscribe(
      (data: userprofile)=> 
      {
        console.log(data);
        this.allCust = data;
        console.log(this.allCust);
        //this.tempEmployees = data; //copied into a temp array also
      }, 
      (err) => {
        console.log(err);
      }
    );

  }

}
