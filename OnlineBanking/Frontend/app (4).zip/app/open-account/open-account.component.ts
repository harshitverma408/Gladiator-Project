import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AddPayeeService } from '../add-payee.service';
import { CustomerDetails } from './CustomerDetails';

@Component({
  selector: 'app-open-account',
  templateUrl: './open-account.component.html',
  styleUrls: ['./open-account.component.css']
})
export class OpenAccountComponent implements OnInit {

  

  cust: CustomerDetails = new CustomerDetails();
  custidDetails:CustomerDetails=new CustomerDetails();

  constructor(private addCust:AddPayeeService,private router:Router) { }

  ngOnInit(): void {
  }

  addCustomer(){
    console.log(this.cust.title);
    console.log("payee getting added");
    this.addCust.addCustomerService(this.cust).subscribe(
      (data: CustomerDetails)=> 
      {
        
        console.log(data);
        this.custidDetails=data;
        sessionStorage.setItem("userKey",JSON.stringify(this.custidDetails));
        
        // this.payee= new Payee();
        
        //copied into a temp array also
      }, 
      (err) => {
        console.log(err);
      }
    );

  }

  home(){
    this.addCustomer();
    this.router.navigate(['/add-account']);
  }

}
