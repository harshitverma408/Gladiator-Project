import { Component, OnInit } from '@angular/core';
import { AddPayeeService } from '../add-payee.service';
import { AccDetails } from './AccDetails';

@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.css']
})
export class AccountDetailsComponent implements OnInit {

  allAcc:AccDetails[]=[];
  temp:any;
  myUser:AccDetails;
  allLogin:AccDetails

  constructor(private accountservice:AddPayeeService) {
    this.temp=sessionStorage.getItem("userKey");
     this.allLogin=JSON.parse(this.temp);
     console.log(this.allLogin);
    console.log("Printing account details...")
    // console.log(this.myUser.userid);
    // console.log(this.myUser);

   }

  ngOnInit(): void {

    this.loadAccount();
  }
  loadAccount() {
    console.log('Load account details');
    this.accountservice.getAccountService(this.allLogin).subscribe(
      (data:AccDetails[])=> 
      {
        
        this.allAcc = data;
        console.log(this.allAcc);
        //this.tempEmployees = data; //copied into a temp array also
      }, 
      (err) => {
        console.log(err);
      }
    );

    
  }
}
