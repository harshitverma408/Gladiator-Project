export class AccDetails{
    cid: number;
    accountlock: String;
    accountstatus: String;
    accounttype: String;
    createdon: Date;
    currentbalance: number;
    loginpassword: String;
    transactionpassword: String;
    userid: String;
    accountnumber: number;
    custId: number;
}