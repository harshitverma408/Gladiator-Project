import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccDetails } from '../account-details/AccDetails';
import { AddPayeeService } from '../add-payee.service';
import { TransactionComponent } from '../transaction/transaction.component';
import { Transaction } from './Transaction';

@Component({
  selector: 'app-rtgs',
  templateUrl: './rtgs.component.html',
  styleUrls: ['./rtgs.component.css']
})
export class RtgsComponent implements OnInit {
  allfunds:Transaction=new Transaction();
 
  allLogin:AccDetails;
  temp:any;
  constructor(private fundservice:AddPayeeService, private router:Router) { 
    this.temp=sessionStorage.getItem("userKey");
     this.allLogin=JSON.parse(this.temp);
     this.allfunds.fromAccountNumber=this.allLogin.accountnumber;
  }

  ngOnInit(): void {
    
  }

  fundtransfer(){
    this.fundservice.fundtransferservice(this.allfunds,this.allLogin).subscribe(
      
        (data: Transaction)=> 
        {
          //this.alltrans = data;
           //copied into a temp array also
           console.log("hi");
        }, 
        (err) => {
          console.log(err);
        }
      );
    
    }
  showTransactionDetails(){
    this.fundtransfer();
    this.router.navigate(['/transaction']);
  }
}
