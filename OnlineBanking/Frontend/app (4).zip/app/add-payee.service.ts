import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Payee } from './add-payee/Payee';
import { Transaction } from './account-statement/Transaction';
import { userprofile } from './user-profile/userprofile';
import { CustomerDetails } from './open-account/CustomerDetails';
import { Approvals } from './approval/Approvals';
import { ApprovalComponent } from './approval/approval.component';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { Account } from './account-input/Account';
import { AccDetails } from './account-details/AccDetails';

@Injectable({
  providedIn: 'root'
})
export class AddPayeeService {
  postPayee = 'addPayee/10008'
  baseURL: string = 'http://localhost:8085/payee/addPayee/'
  getURL: string = 'http://localhost:8085/payee/getPayee/'
  transURL: string = 'http://localhost:8085/transaction/getTrans/'
  custURL: string = 'http://localhost:8085/customer/getCustomer/'
  loginURL: string = 'http://localhost:8085/loginpage/login/'
  accURL: string = 'http://localhost:8085/account/getAccountOnAccno/'
  custAddURL: string = 'http://localhost:8085/customer/addCust'
  setpwURL = 'http://localhost:8085/setPass/login'
  approveURL: string = 'http://localhost:8085/approval/approveAccount'
  approvalURL: string = 'http://localhost:8085/approval/accToApprove'
  fundurl = 'http://localhost:8085/transfer/addFund/'
  addAccountURL: string = 'http://localhost:8085/account/addAccount'
  ans: string;

  constructor(private myhttp: HttpClient) { }
  //insert payee
  addPayeeService(payee: Payee, allLogin: AccDetails): Observable<any> {

    console.log(payee);
    return this.myhttp.post<any>(this.baseURL + '/' + allLogin.accountnumber, payee);
  }
  //get payees
  getPayeeService(allLogin: AccDetails): Observable<Payee[]> {
    console.log("getPayeeservice called..")
    return this.myhttp.get<Payee[]>(this.getURL + '/' + allLogin.accountnumber);
  }
  //getaccountstatement
  getTransactionService(allLogin: AccDetails): Observable<Transaction[]> {
    console.log("getPayeeservice called..")
    console.log(allLogin.accountnumber);
    return this.myhttp.get<Transaction[]>(this.transURL + '/' + allLogin.accountnumber);
  }
  // deletePayeeService(empNo : number) : Observable<string> {//eno is copied here to empNo
  //   return this.myhttp.delete<string>(this.baseURL+"deleteEmp/"+empNo);
  // }

  //getCustomerDetails
  getCustomerService(allAcc: AccDetails): Observable<userprofile> {
    console.log("getCustomer called...");
    console.log(allAcc.custId);
    return this.myhttp.get<userprofile>(this.custURL + '/' + allAcc.custId);
  }

  getLoginService(allLogin: AccDetails): Observable<any> {
    console.log("getLoginService called...");
    //console.log(allLogin);
    return this.myhttp.get<any>(this.loginURL + allLogin.userid + '/' + allLogin.loginpassword);
  }
  getAccountService(allLogin: AccDetails): Observable<AccDetails[]> {
    console.log("getAccount called...");
    console.log(allLogin.accountnumber);
    return this.myhttp.get<AccDetails[]>(this.accURL + '/' + allLogin.accountnumber);
  }
  addCustomerService(cust: CustomerDetails): Observable<any> {

    console.log(cust);
    console.log("post is working");
    return this.myhttp.post<any>(this.custAddURL, cust);
    // return this.myhttp.post('${this.baseURL}',payee);
    // return this.http.post(`${this.baseUrl}`+'/addquestion', addQuestion)

  }
  forgotPassword(loginpassword, accountnumber): Observable<any> {
    console.log("getpasswordService called...");
    //console.log(allLogin);
    //console.log(this.setpwURL+loginpassword+'/'+accountnumber);
    this.ans = loginpassword + '/' + accountnumber;
    console.log(this.ans);
    return this.myhttp.get<any>(this.setpwURL + loginpassword + '/' + accountnumber);
  }

  getApprovalService(): Observable<Approvals[]> {
    console.log("getPayeeservice called..")
    return this.myhttp.get<Approvals[]>(this.approvalURL);
  }

  approveservice(allApprovals: Approvals): Observable<any> {

    console.log("approve service called..")
    console.log(allApprovals.custId);
    //console.log(appr);

    return this.myhttp.post<any>(this.approveURL + '/' + allApprovals.custId + '/' + 55599, {});
  }


  fundtransferservice(allfunds: Transaction, allLogin: AccDetails): Observable<any> {

    console.log(allfunds);
    console.log(allfunds.toAccountNumber);

    return this.myhttp.post<any>(this.fundurl + '/' + allfunds.toAccountNumber + '/' + allfunds.fromAccountNumber, allfunds);
  }

  addAccountService(addAccount: Account, custidDetails: CustomerDetails): Observable<any> {

    console.log(addAccount);
    console.log("account  is working");
    console.log(custidDetails.custid);

    return this.myhttp.post<any>(this.addAccountURL + '/' + custidDetails.custid, addAccount);
    // return this.myhttp.post('${this.baseURL}',payee);
    // return this.http.post(`${this.baseUrl}`+'/addquestion', addQuestion)

  }
 

}