import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAllPayeeComponent } from './view-all-payee.component';

describe('ViewAllPayeeComponent', () => {
  let component: ViewAllPayeeComponent;
  let fixture: ComponentFixture<ViewAllPayeeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAllPayeeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAllPayeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
