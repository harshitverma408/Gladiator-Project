import { Component, OnInit } from '@angular/core';
import { AccDetails } from '../account-details/AccDetails';
import { AddPayeeService } from '../add-payee.service';
import { Payee } from '../add-payee/Payee';

@Component({
  selector: 'app-view-all-payee',
  templateUrl: './view-all-payee.component.html',
  styleUrls: ['./view-all-payee.component.css']
})
export class ViewAllPayeeComponent implements OnInit {

  bid:number=0;
  allPayee:Payee[]=[];
  tempPayees:Payee[]=[];
  xdata: any;
  deleted: Boolean;
  allLogin:AccDetails;
  temp:any;

  constructor(private payeeservice:AddPayeeService) {
    this.temp=sessionStorage.getItem("userKey");
     this.allLogin=JSON.parse(this.temp);
   }

  ngOnInit(): void {

    console.log("loading payees");
    this.loadAllEmployees();

  }
  loadAllEmployees() {
    console.log('Load all payees');
    this.payeeservice.getPayeeService(this.allLogin).subscribe(
      (data: Payee[])=> 
      {
        this.allPayee = data;
        //this.tempEmployees = data; //copied into a temp array also
      }, 
      (err) => {
        console.log(err);
      }
    );

  }

}
