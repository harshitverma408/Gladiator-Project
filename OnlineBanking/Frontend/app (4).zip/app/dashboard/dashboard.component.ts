import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  home(){
    this.router.navigate(['/home']);
  }
  imps(){
    this.router.navigate(['/imps']);
  }
  rtgs(){
    this.router.navigate(['/rtgs']);

  }
  neft(){
    this.router.navigate(['/neft']);

  }
  addPayee(){
    this.router.navigate(['/dashboard/add-payee']);
  }
  userProfile(){
    this.router.navigate(['/dashboard/profile']);
  }
  setNewPassword(){
    this.router.navigate(['/set-new-pw']);
  }
  setNewUserId(){
    this.router.navigate(['/set-new-user-id']);
  }
  accountDetails(){
    this.router.navigate(['/dashboard/account-details']);
  }
  accountSummary(){
    this.router.navigate(['/dashboard/account-summary']);
  }
  viewAllPayee(){
    this.router.navigate(['/dashboard/view-payee']);

  }
  forgotPassword(){
    this.router.navigate(['/forgot-pw']);
  }

}
