import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccDetails } from '../account-details/AccDetails';
import { AddPayeeService } from '../add-payee.service';

@Component({
  selector: 'app-set-new-password',
  templateUrl: './set-new-password.component.html',
  styleUrls: ['./set-new-password.component.css']
})
export class SetNewPasswordComponent implements OnInit {

  accountnumber:number;
  loginpassword:string;
  password:AccDetails=new AccDetails();

  constructor(private passwordservice:AddPayeeService,private router:Router) { }

  ngOnInit(): void {
  }

  forgotpassword(loginpassword,accountnumber){
    console.log("inside authenticate...")
    console.log(this.accountnumber);
    console.log(this.loginpassword);
    this.passwordservice.forgotPassword(loginpassword,accountnumber).subscribe(
      ( data:AccDetails)=>
      {

        console.log(data);
        if(data==null){
       
        console.log("Response received");
        alert("Your password has been reset");
         this.router.navigate(['/login']);
        }else{
          console.log("invalid user credentials");
        } 
         
       },
       (err)=>{
        console.log(err);
       }
    );
    this.login();
    }
  login(){
    console.log('login called')
    this.router.navigate(['/login']);
  }

}
