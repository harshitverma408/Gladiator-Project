import { Component, OnInit } from '@angular/core';
import { AccDetails } from '../account-details/AccDetails';
import { AddPayeeService } from '../add-payee.service';
import { Payee } from './Payee';

@Component({
  selector: 'app-add-payee',
  templateUrl: './add-payee.component.html',
  styleUrls: ['./add-payee.component.css']
})
export class AddPayeeComponent implements OnInit {
  allLogin:AccDetails;
  temp:any

  constructor(private addBeneficiary:AddPayeeService) {
    this.temp=sessionStorage.getItem("userKey");
    this.allLogin=JSON.parse(this.temp);
   }

  payee: Payee = new Payee();

  ngOnInit(): void {

    
}

addPayee(){
  console.log("payee getting added");
  this.addBeneficiary.addPayeeService(this.payee,this.allLogin).subscribe(
    (data: Payee)=> 
    {
      // this.payee= new Payee();
      
      //copied into a temp array also
    }, 
    (err) => {
      console.log(err);
    }
  );
  }
}





