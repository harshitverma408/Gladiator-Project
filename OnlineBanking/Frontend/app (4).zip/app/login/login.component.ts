import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccDetails } from '../account-details/AccDetails';

import { AddPayeeService } from '../add-payee.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  allLogin: AccDetails=new AccDetails();
  userid: String;
  loginpassword:String;
  logincheck:boolean;

  constructor(private loginservice:AddPayeeService,private router:Router) { }

  ngOnInit(): void {
    //console.log("authenticating..");
    //this.authenticate(userid,login);
  }
  authenticate(){
    console.log("inside authenticate...")
    this.loginservice.getLoginService(this.allLogin).subscribe(
      ( data:AccDetails)=>
      {
        console.log("Printing data")
        console.log(data);
       if(data.toString()!=null){
        //  this.logincheck=true;
        //  console.log(this.logincheck);
         console.log("Printing acc details");
         this.allLogin=data;
         console.log(this.allLogin);
         sessionStorage.setItem("userKey",JSON.stringify(this.allLogin));
         this.router.navigate(['/dashboard']);
         
       }
       else{
         this.logincheck=false;
    
       }
       
        //this.allLogin = data;
        //console.log(this.allLogin);
        // console.log("Response received");
         
         
         //console.log("navigating");
         
         
    },
     
  
          //copied into temp array
      (err)=>{
          console.log(err);
      }
    );
    
  }
  gotodashboard(){
    //this.authenticate();
    
    }
  





    //this.router.navigate(['/dashboard'])
  
  registerIb(){
    this.router.navigate(['/register-ib']);
  }
 forgotPassword(){
    this.router.navigate(['/forgot-pw']);
  }
 forgotUserId(){
    this.router.navigate(['/forgot-id']);
  }
  goToDashBoard(){
    this.authenticate();
    this.router.navigate(['/dashboard']);


  }

}
