import { Component, OnInit } from '@angular/core';
import { AccDetails } from '../account-details/AccDetails';
import { AddPayeeService } from '../add-payee.service';
import { Transaction } from './Transaction';

@Component({
  selector: 'app-account-statement',
  templateUrl: './account-statement.component.html',
  styleUrls: ['./account-statement.component.css']
})
export class AccountStatementComponent implements OnInit {

  allTransaction:Transaction[]=[];
  temp:any;
  allLogin:AccDetails;

  constructor(private transactionservice:AddPayeeService) {
    this.temp=sessionStorage.getItem("userKey");
     this.allLogin=JSON.parse(this.temp);
    
   }

  ngOnInit(): void {

    console.log("loading payees");
    this.loadAllEmployees();

  }
  loadAllEmployees() {
    console.log('Load all transactions');
    this.transactionservice.getTransactionService(this.allLogin).subscribe(
      (data: Transaction[])=> 
      {
        this.allTransaction = data;
        //this.tempEmployees = data; //copied into a temp array also

        console.log(this.allTransaction);
      }, 
      (err) => {
        console.log(err);
      }
    );

  }
}
