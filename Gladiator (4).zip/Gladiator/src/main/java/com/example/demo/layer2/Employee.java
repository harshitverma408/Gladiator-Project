package com.example.demo.layer2;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;

@Entity
public class Employee {
	
	@Id
	@GeneratedValue
	private int Appid;
	
	private String Empname;
	
	@OneToOne
	@MapsId
	@JoinColumn(name="Appid")
	Application app;
	
	
	public int getAppid() {
		return Appid;
	}

	public void setAppid(int appid) {
		Appid = appid;
	}

	public String getEmpname() {
		return Empname;
	}

	public void setEmpname(String empname) {
		Empname = empname;
	}

	public Employee(int appid, String empname) {
		super();
		Appid = appid;
		Empname = empname;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
