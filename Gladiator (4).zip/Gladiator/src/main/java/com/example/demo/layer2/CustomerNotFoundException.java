package com.example.demo.layer2;

public class CustomerNotFoundException extends Exception {
	public CustomerNotFoundException(String str) {
		super(str);
	}
}