package com.example.demo.layer3;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;

import com.example.demo.layer2.Application;

@Repository
public class ApplicationRepoIMPL extends BaseRepository implements ApplicationRepo{

	@Override
	public List<Application> getAllApplicants() {
		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery("from Application");
		return query.getResultList();
	}

}
