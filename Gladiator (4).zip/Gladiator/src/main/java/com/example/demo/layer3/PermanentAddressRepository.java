package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.PermanentAddressNotFoundException;
import com.example.demo.layer2.Permanentaddress;


@Repository
public interface PermanentAddressRepository {
	
	void insertPermanentAddress(Permanentaddress ref);
	Permanentaddress selectPermanentAddress(int PermanentId) throws PermanentAddressNotFoundException;
	List<Permanentaddress> selectAllPermanentAddress();

}
