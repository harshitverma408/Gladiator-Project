package com.example.demo.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Application;
import com.example.demo.layer2.CustomerNotFoundException;
import com.example.demo.layer2.Customerdetail;
import com.example.demo.layer3.ApplicationRepoIMPL;
import com.example.demo.layer3.CustomerReositoryIMPL;

@RestController
@RequestMapping(value = "/application")
public class ApplicationJPAController {
	
	@Autowired
	ApplicationRepoIMPL appRepo;
	
	
	public ApplicationJPAController() {
		System.out.println("AppliationJPAController() Created");
	}
	
	
	@GetMapping
	@ResponseBody
	@RequestMapping(value = "/getAllApp")
	public List<Application> getAllApplicants(){
		return appRepo.getAllApplicants();
	}

}
