package com.example.demo.layer3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.CustomerNotFoundException;
import com.example.demo.layer2.Customerdetail;

@Repository
public class CustomerReositoryIMPL extends BaseRepository implements CustomerRepository{

	@Transactional
	public void insertCustomer(Customerdetail ref) {
		EntityManager entityManager = getEntityManager();
		entityManager.persist(ref);
		System.out.println("Customer inserted..."+ref);
	}

	@Override
	public Customerdetail selectCustomer(int CustId) throws CustomerNotFoundException {
		EntityManager entityManager = getEntityManager();
		return entityManager.find(Customerdetail.class, CustId);
	}

	@Override
	public List<Customerdetail> selectAllCustomers() {
		System.out.println("customerRepository : Layer 3");
		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery("from Customerdetail");
		List<Customerdetail> CustomerDetailsList = query.getResultList();
		return CustomerDetailsList;
	}


	@Override
	public void updateCustomer(Customerdetail Customer) throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteCustomer(int CustId) throws CustomerNotFoundException {
		EntityManager entityManager = getEntityManager();
		Customerdetail foundCust = entityManager.find(Customerdetail.class, CustId);
		if(foundCust!=null)
		entityManager.remove(foundCust);
		else
			throw new CustomerNotFoundException("Customer Not Found : "+CustId);
		System.out.println("Entitymanager: entity removed ... ");
		
	}

	@Override
	public void selectCutomerOnGrossIncome(String gross) {
		//this method should return all values based on the GrossAnnualIncome
	}

}
