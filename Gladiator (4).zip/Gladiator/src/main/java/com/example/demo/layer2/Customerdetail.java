package com.example.demo.layer2;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the CUSTOMERDETAILS database table.
 * 
 */
@Entity
@Table(name="CUSTOMERDETAILS")
@NamedQuery(name="Customerdetail.findAll", query="SELECT c FROM Customerdetail c")
public class Customerdetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long custid;

	private String debitcard;

	@Temporal(TemporalType.DATE)
	private Date dob;

	private String email;

	private String fathername;

	private String firstname;

	private String grossannualincome;

	private String incomesource;

	private double initialamount;

	private String lastname;

	private String middlename;

	private String mobilenumber;

	private String occupationtype;

	private String optnetbanking;

	public long getAadharnumber() {
		return aadharnumber;
	}

	private String title;
	
	private long aadharnumber;
	
	public void setAadharnumber(long aadharnumber) {
		this.aadharnumber = aadharnumber;
	}


	
	//bi-directional one-to-one association to Permanentaddress
	@OneToOne(mappedBy = "customerdetail",cascade = CascadeType.ALL)
	@PrimaryKeyJoinColumn
	Permanentaddress permanentaddress;
	
	//bi-directional one-to-one association to Residentialaddress
	@OneToOne(mappedBy = "customerdetail",cascade = CascadeType.ALL)
	@PrimaryKeyJoinColumn
	Residentialaddress residentialaddress;
	
	

	public Residentialaddress getResidentialaddress() {
		return residentialaddress;
	}

	public void setResidentialaddress(Residentialaddress residentialaddress) {
		this.residentialaddress = residentialaddress;
	}

	public Customerdetail() {
	}

	public long getCustid() {
		return this.custid;
	}

	public void setCustid(long custid) {
		this.custid = custid;
	}

	public String getDebitcard() {
		return this.debitcard;
	}

	public void setDebitcard(String debitcard) {
		this.debitcard = debitcard;
	}

	public Date getDob() {
		return this.dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFathername() {
		return this.fathername;
	}

	public void setFathername(String fathername) {
		this.fathername = fathername;
	}

	public String getFirstname() {
		return this.firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getGrossannualincome() {
		return this.grossannualincome;
	}

	public void setGrossannualincome(String grossannualincome) {
		this.grossannualincome = grossannualincome;
	}

	public String getIncomesource() {
		return this.incomesource;
	}

	public void setIncomesource(String incomesource) {
		this.incomesource = incomesource;
	}

	public double getInitialamount() {
		return this.initialamount;
	}

	public void setInitialamount(double initialamount) {
		this.initialamount = initialamount;
	}

	public String getLastname() {
		return this.lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getMiddlename() {
		return this.middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public String getMobilenumber() {
		return this.mobilenumber;
	}

	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}

	public String getOccupationtype() {
		return this.occupationtype;
	}

	public void setOccupationtype(String occupationtype) {
		this.occupationtype = occupationtype;
	}

	public String getOptnetbanking() {
		return this.optnetbanking;
	}

	public void setOptnetbanking(String optnetbanking) {
		this.optnetbanking = optnetbanking;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Permanentaddress getPermanentaddress() {
		return this.permanentaddress;
	}

	public void setPermanentaddress(Permanentaddress permanentaddress) {
		this.permanentaddress = permanentaddress;
	}

}

