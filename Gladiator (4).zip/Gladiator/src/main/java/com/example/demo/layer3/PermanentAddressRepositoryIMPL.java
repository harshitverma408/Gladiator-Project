package com.example.demo.layer3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.PermanentAddressNotFoundException;
import com.example.demo.layer2.Permanentaddress;

@Repository
public class PermanentAddressRepositoryIMPL extends BaseRepository implements PermanentAddressRepository{

	@Override
	public void insertPermanentAddress(Permanentaddress ref) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Permanentaddress selectPermanentAddress(int PermanentId) throws PermanentAddressNotFoundException {
		EntityManager entityManager = getEntityManager();
		return entityManager.find(Permanentaddress.class, PermanentId);
	}

	@Override
	public List<Permanentaddress> selectAllPermanentAddress() {
		System.out.println("PermanentAddressRepository : Layer 3");
		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery("from Permanentaddress");
		List<Permanentaddress> PermanentAddressList = query.getResultList();
		return PermanentAddressList;
	}
	

}
