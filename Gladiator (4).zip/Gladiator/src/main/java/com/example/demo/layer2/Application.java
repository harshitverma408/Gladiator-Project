package com.example.demo.layer2;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
public class Application {
	
	@Id
	@GeneratedValue
	private int Appid;
	
	private String Appname;
	
	@OneToOne(mappedBy = "app",cascade = CascadeType.ALL)
	@PrimaryKeyJoinColumn
	Employee employee;

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public int getAppid() {
		return Appid;
	}

	public void setAppid(int appid) {
		Appid = appid;
	}

	public String getAppname() {
		return Appname;
	}

	public void setAppname(String appname) {
		Appname = appname;
	}

	public Application(int appid, String appname) {
		super();
		Appid = appid;
		Appname = appname;
	}

	public Application() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
