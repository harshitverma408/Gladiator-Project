package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GladiatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(GladiatorApplication.class, args);
		System.out.println("hi this is working ");
	}

}
