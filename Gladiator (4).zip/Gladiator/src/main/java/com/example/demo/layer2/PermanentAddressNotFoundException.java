package com.example.demo.layer2;

public class PermanentAddressNotFoundException extends Exception {
	public PermanentAddressNotFoundException(String str) {
		super(str);
	}

}
