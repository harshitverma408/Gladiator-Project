package com.example.demo.layer2;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;

@Entity
@NamedQuery(name="Permanentaddress.findAll", query="SELECT p FROM Permanentaddress p")
public class Permanentaddress implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	private long custid;

	private String city;

	private String landmark;

	private String line1;

	private String line2;

	private BigDecimal pincode;

	private String state;

	
	@OneToOne
	@MapsId
	@JoinColumn(name="custid")
	Customerdetail customerdetail;

	public Permanentaddress() {
	}

	public long getCustId() {
		return this.custid;
	}

	public void setCustId(long CustId) {
		this.custid = CustId;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getLandmark() {
		return this.landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getLine1() {
		return this.line1;
	}

	public void setLine1(String line1) {
		this.line1 = line1;
	}

	public String getLine2() {
		return this.line2;
	}

	public void setLine2(String line2) {
		this.line2 = line2;
	}

	public BigDecimal getPincode() {
		return this.pincode;
	}

	public void setPincode(BigDecimal pincode) {
		this.pincode = pincode;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}
	

}