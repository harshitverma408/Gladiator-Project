package com.example.demo.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.PermanentAddressNotFoundException;
import com.example.demo.layer2.Permanentaddress;
import com.example.demo.layer3.PermanentAddressRepositoryIMPL;


@RestController
@RequestMapping(value = "/permanentaddress")
public class PermanentAddressJPAController {
	
		
		@Autowired
		PermanentAddressRepositoryIMPL p;
		
		
		public PermanentAddressJPAController() {
			System.out.println("PermanentAddressJPAController() Created");
		}
		
		
		@GetMapping
		@ResponseBody
		@RequestMapping(value = "/greet", method = RequestMethod.GET)
		String greetEmployee() {
			
			return "Hello PermanentAddress";

		}
		
		@GetMapping
		@ResponseBody
		@RequestMapping(value = "/getPermanentAddress/{permanentId}")
		public Permanentaddress getEmployee(@PathVariable int permanentId) {
			System.out.println("getPermanentAddress()...method ");
			
			try {
				return p.selectPermanentAddress(permanentId);
			} catch (PermanentAddressNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
			
		}
		
		@GetMapping
		@ResponseBody
		@RequestMapping(value = "/getAllPermanentAddress")
		public List<Permanentaddress> getAllPermanentAddresss(){
			return p.selectAllPermanentAddress();
		}

	}

