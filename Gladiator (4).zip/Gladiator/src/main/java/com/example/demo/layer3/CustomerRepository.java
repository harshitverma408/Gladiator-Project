package com.example.demo.layer3;


import java.util.List;

import org.springframework.stereotype.Repository;
import com.example.demo.layer2.CustomerNotFoundException;
import com.example.demo.layer2.Customerdetail;


//IF THIS INTERFACE DESIGNED BY THE TEAM LEADER ( WITH GROUP DISCUSSION )

@Repository
public interface CustomerRepository {
	
	void insertCustomer(Customerdetail ref);
	Customerdetail selectCustomer(int CustId) throws CustomerNotFoundException;
	List<Customerdetail> selectAllCustomers();
	
	void selectCutomerOnGrossIncome(String gross);
	void updateCustomer(Customerdetail Customer) throws CustomerNotFoundException;
	void deleteCustomer(int CustId) throws CustomerNotFoundException;
}