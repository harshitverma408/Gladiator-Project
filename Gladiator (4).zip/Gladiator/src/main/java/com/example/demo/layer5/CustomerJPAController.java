package com.example.demo.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.CustomerNotFoundException;
import com.example.demo.layer2.Customerdetail;
import com.example.demo.layer3.CustomerReositoryIMPL;

@RestController
@RequestMapping(value = "/customer")
public class CustomerJPAController {
	
	@Autowired
	CustomerReositoryIMPL c;
	
	
	public CustomerJPAController() {
		System.out.println("EmployeeJPAController() Created");
	}
	
	
	@GetMapping
	@ResponseBody
	@RequestMapping(value = "/greet", method = RequestMethod.GET)
	String greetEmployee() {
		
		return "Hello customer";

	}
	
	@GetMapping
	@ResponseBody
	@RequestMapping(value = "/getCustomer/{custId}")
	public Customerdetail getEmployee(@PathVariable int CustId) {
		System.out.println("getEmployee()...method ");
		
		try {
			return c.selectCustomer(CustId);
		} catch (CustomerNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
	
	@GetMapping
	@ResponseBody
	@RequestMapping(value = "/getAllCustomers")
	public List<Customerdetail> getAllCustomers(){
		return c.selectAllCustomers();
	}

}
