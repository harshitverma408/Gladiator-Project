import { Component, OnInit } from '@angular/core';
import { AddPayeeService } from '../add-payee.service';
import { Transaction } from './Transaction';

@Component({
  selector: 'app-account-statement',
  templateUrl: './account-statement.component.html',
  styleUrls: ['./account-statement.component.css']
})
export class AccountStatementComponent implements OnInit {

  allTransaction:Transaction[]=[];

  constructor(private transactionservice:AddPayeeService) { }

  ngOnInit(): void {

    console.log("loading payees");
    this.loadAllTransactions();

  }
  loadAllTransactions() {
    console.log('Load all transactions');
    this.transactionservice.getTransactionService().subscribe(
      (data: Transaction[])=> 
      {
        this.allTransaction = data;
        //this.tempEmployees = data; //copied into a temp array also
      }, 
      (err) => {
        console.log(err);
      }
    );

  }
}
