import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-neft',
  templateUrl: './neft.component.html',
  styleUrls: ['./neft.component.css']
})
export class NeftComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  showTransactionDetails(){
    this.router.navigate(['/transaction']);
  }

}
