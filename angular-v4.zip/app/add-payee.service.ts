import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Payee } from './add-payee/Payee';
import { Transaction } from './account-statement/Transaction';
import { userprofile } from './user-profile/userprofile';
import { CustomerDetails } from './open-account/CustomerDetails';

@Injectable({
  providedIn: 'root'
})
export class AddPayeeService {

 
  postPayee = 'addPayee/10008'
  baseURL: string = 'http://localhost:8085/payee/addPayee/10008'
  getURL:string='http://localhost:8085/payee/getPayee/10008'
  transURL:string='http://localhost:8085/transaction/getTrans/10008'
  custURL:string='http://localhost:8085/customer/getCustomer/101'
  custAddURL:string='http://localhost:8085/customer/addCust'
  constructor(private myhttp: HttpClient) { }

  addPayeeService(payee:Payee): Observable<any> {
    
    console.log(payee);
    console.log("post is working");
    return this.myhttp.post<any>(this.baseURL,payee);
    // return this.myhttp.post('${this.baseURL}',payee);
    // return this.http.post(`${this.baseUrl}`+'/addquestion', addQuestion)
    
}
getPayeeService(): Observable<Payee[]> {
  console.log("getPayeeservice called..")
 return this.myhttp.get<Payee[]>(this.getURL);
}
 getTransactionService(): Observable<Transaction[]> {
 console.log("getPayeeservice called..")
 return this.myhttp.get<Transaction[]>(this.transURL);
}

getCustomerService():Observable<userprofile>
{
  console.log("getCustomer called...");
  return this.myhttp.get<userprofile>(this.custURL);
}

addCustomerService(cust:CustomerDetails): Observable<any> {
    
  console.log(cust);
  console.log("post is working");
  return this.myhttp.post<any>(this.custAddURL,cust);
  // return this.myhttp.post('${this.baseURL}',payee);
  // return this.http.post(`${this.baseUrl}`+'/addquestion', addQuestion)
  
}

}
