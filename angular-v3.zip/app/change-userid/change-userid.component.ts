import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-change-userid',
  templateUrl: './change-userid.component.html',
  styleUrls: ['./change-userid.component.css']
})
export class ChangeUseridComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  dashboard(){
    this.router.navigate(['/dashboard']);
  }
}
