import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register-internet-banking',
  templateUrl: './register-internet-banking.component.html',
  styleUrls: ['./register-internet-banking.component.css']
})
export class RegisterInternetBankingComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  login(){
    this.router.navigate(['/login']);
  }

}
