export class Payee{
 
    // beneficaryid:number;
    beneficiaryname:any;
    nickname:String;
    baccountnumber:number;
    
 
}