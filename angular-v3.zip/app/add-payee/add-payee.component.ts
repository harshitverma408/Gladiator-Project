import { Component, OnInit } from '@angular/core';
import { AddPayeeService } from '../add-payee.service';
import { Payee } from './Payee';

@Component({
  selector: 'app-add-payee',
  templateUrl: './add-payee.component.html',
  styleUrls: ['./add-payee.component.css']
})
export class AddPayeeComponent implements OnInit {
  payee: Payee = new Payee();

  constructor(private addBeneficiary:AddPayeeService) { }

  ngOnInit(): void {
  }

  addPayee(){
    console.log("payee getting added");
    this.addBeneficiary.addPayeeService(this.payee).subscribe(
      (data: Payee)=> 
      {
        // this.payee= new Payee();
        
        //copied into a temp array also
      }, 
      (err) => {
        console.log(err);
      }
    );


  }

}



