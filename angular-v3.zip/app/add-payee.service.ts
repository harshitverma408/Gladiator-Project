import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Payee } from './add-payee/Payee';
import { Transaction } from './account-statement/Transaction';
@Injectable({
  providedIn: 'root'
})
export class AddPayeeService {

 
  postPayee = 'addPayee/10008'
  baseURL: string = 'http://localhost:8085/payee/addPayee/10008'
  getURL:string='http://localhost:8085/payee/getPayee/10008'
  transURL:string='http://localhost:8085/transaction/getTrans/10008'
  
  constructor(private myhttp: HttpClient) { }

  addPayeeService(payee:Payee): Observable<any> {
    
    console.log(payee);
    return this.myhttp.post<any>(this.baseURL,payee);
    // return this.myhttp.post('${this.baseURL}',payee);
    // return this.http.post(`${this.baseUrl}`+'/addquestion', addQuestion)
    console.log("post is working");
}
getPayeeService(): Observable<Payee[]> {
  console.log("getPayeeservice called..")
 return this.myhttp.get<Payee[]>(this.getURL);
}
 getTransactionService(): Observable<Transaction[]> {
 console.log("getPayeeservice called..")
 return this.myhttp.get<Transaction[]>(this.transURL);
}
}
