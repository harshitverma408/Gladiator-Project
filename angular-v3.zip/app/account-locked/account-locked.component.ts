import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-locked',
  templateUrl: './account-locked.component.html',
  styleUrls: ['./account-locked.component.css']
})
export class AccountLockedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
