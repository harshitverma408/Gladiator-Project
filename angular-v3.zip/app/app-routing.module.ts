import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { AccountLockedComponent } from './account-locked/account-locked.component';
import { AccountStatementComponent } from './account-statement/account-statement.component';
import { AccountSummaryComponent } from './account-summary/account-summary.component';
import { AddPayeeComponent } from './add-payee/add-payee.component';
import { AdminComponent } from './admin/admin.component';
import { AppComponent } from './app.component';
import { ApprovalComponent } from './approval/approval.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { ChangeUseridComponent } from './change-userid/change-userid.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ForgotUseridComponent } from './forgot-userid/forgot-userid.component';
import { HomeComponent } from './home/home.component';
import { ImpsComponent } from './imps/imps.component';
import { LoginComponent } from './login/login.component';
import { NeftComponent } from './neft/neft.component';
import { OpenAccountComponent } from './open-account/open-account.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { RegisterInternetBankingComponent } from './register-internet-banking/register-internet-banking.component';
import { RtgsComponent } from './rtgs/rtgs.component';
import { TransactionComponent } from './transaction/transaction.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { ViewAllPayeeComponent } from './view-all-payee/view-all-payee.component';

const routes: Routes = [
  {path:'',redirectTo:'home',pathMatch:'full'},
  {path:'home',component:HomeComponent},
  
  {path:'login',component:LoginComponent,
  children:[
    
    

  ]
},
   {path:'dashboard',component:DashboardComponent,
   children:[
    {path:'account-statement',component:AccountStatementComponent},
    {path:'add-payee',component:AddPayeeComponent},
    {path:'profile',component:UserProfileComponent},
    {path:'account-details',component:AccountDetailsComponent},
    {path:'account-summary',component:AccountSummaryComponent},
    {path:'view-payee',component:ViewAllPayeeComponent}
    

  ]},
  {path:'admin',component:AdminComponent},
  {path:'rtgs',component:RtgsComponent},
  {path:'neft',component:NeftComponent},
  {path:'imps',component:ImpsComponent},
  {path:'forgot-pw',component:ForgotPasswordComponent},
  {path:'forgot-id',component:ForgotUseridComponent},
  {path:'register-ib',component:RegisterInternetBankingComponent},
  {path:'open-account',component:OpenAccountComponent},
  {path:'account-lock',component:AccountLockedComponent},
  {path:'set-new-pw',component:ChangePasswordComponent},
  {path:'set-new-user-id',component:ChangeUseridComponent},
  {path:'approval',component:ApprovalComponent},
  {path:'transaction',component:TransactionComponent},
  {path:'**',component:PageNotFoundComponent}
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
